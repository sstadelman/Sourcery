//
//  File.swift
//  
//
//  Created by Stadelman, Stan on 1/11/21.
//

import Foundation
import SourceryRuntime

// MARK: Public API
extension Array where Element == Variable {
    
    public func foo() -> String { "Foo" }
}
