//
//  TestSource.swift
//  
//
//  Created by Stadelman, Stan on 1/11/21.
//

import Foundation

struct Bar {
    let x: Int
    let y: Int
}
